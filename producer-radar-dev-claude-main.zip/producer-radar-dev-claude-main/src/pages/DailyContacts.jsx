import React, { useState, useRef, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api-client';
import { MessageCircle, RefreshCw, Check, Instagram, Mail, Pencil, Shuffle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import PriorityBar from '@/components/shared/PriorityBar';
import StatusBadge from '@/components/shared/StatusBadge';
import ProducerProfile from '@/components/shared/ProducerProfile';
import { toast } from 'sonner';

const styleColors = {
  'Juice WRLD': 'text-purple-400','Polo G': 'text-sky-400','Rod Wave': 'text-teal-400',
  'NBA YoungBoy': 'text-red-400','Melodic Trap': 'text-indigo-400','Emo Trap': 'text-pink-400','Other': 'text-zinc-400',
};

function addDays(n) {
  const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().split('T')[0];
}

function toDateStr(value) {
  if (!value) return null;
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString().slice(0, 10);
}

function randomDays(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRandomOffset(currentStatus) {
  if (currentStatus === 'contactado' || currentStatus === 'follow up 1') return randomDays(1, 5);
  if (currentStatus === 'follow up 2') return randomDays(6, 10);
  if (currentStatus === 'follow up 3' || currentStatus === 'follow up 4') return randomDays(10, 30);
  return 7;
}

function formatFollowUpDate(dateStr) {
  if (!dateStr) return null;
  const today = new Date(); today.setHours(0,0,0,0);
  const d = new Date(dateStr); d.setHours(0,0,0,0);
  const diff = Math.round((d - today) / 86400000);
  if (diff < 0) return { label: `${Math.abs(diff)}d overdue`, color: 'text-red-400' };
  if (diff === 0) return { label: 'Today', color: 'text-amber-400' };
  if (diff === 1) return { label: 'Tomorrow', color: 'text-emerald-400' };
  return { label: `in ${diff}d`, color: 'text-[#71717a]' };
}


function DateChip({ dateStr }) {
  if (!dateStr) return (
    <span className="text-xs px-2 py-0.5 rounded-full border bg-red-500/10 text-red-400 border-red-500/20 whitespace-nowrap">
      No date
    </span>
  );
  const todayStr = new Date().toISOString().split('T')[0];
  if (dateStr < todayStr) {
    const diff = Math.round((new Date(todayStr) - new Date(dateStr)) / 86400000);
    return (
      <span className="text-xs px-2 py-0.5 rounded-full border bg-red-500/10 text-red-400 border-red-500/20 whitespace-nowrap">
        {diff}d overdue
      </span>
    );
  }
  if (dateStr === todayStr) return (
    <span className="text-xs px-2 py-0.5 rounded-full border bg-amber-500/10 text-amber-400 border-amber-500/20 whitespace-nowrap">
      Today
    </span>
  );
  const diff = Math.round((new Date(dateStr) - new Date(todayStr)) / 86400000);
  return (
    <span className="text-xs px-2 py-0.5 rounded-full border bg-zinc-700/50 text-zinc-400 border-zinc-700 whitespace-nowrap">
      in {diff}d
    </span>
  );
}

function GroupHeader({ label, color, count, textColor, badgeClass }) {
  return (
    <div className={`flex items-center gap-2 px-3 sm:px-5 py-2 border-l-2 ${color} bg-white/[0.01]`}>
      <span className={`text-xs font-semibold uppercase tracking-wide ${textColor}`}>{label}</span>
      <span className={`text-[10px] px-1.5 py-0.5 rounded-full border ${badgeClass}`}>{count}</span>
    </div>
  );
}

function getRowKey(producer) {
  return `${producer._type}-${producer.id}`;
}

function getProfileType(producerType) {
  return producerType === 'yt' ? 'youtube' : 'placement';
}

function normalizeDateValue(value) {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return date.toISOString().slice(0, 10);
}

function buildProducerPayload(data) {
  return {
    ...data,
    last_action: normalizeDateValue(data.last_action),
    next_follow_up: normalizeDateValue(data.next_follow_up),
  };
}

export default function DailyContacts() {
  const queryClient = useQueryClient();
  const [editProducer, setEditProducer] = useState(null);
  const [filter, setFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedFollowUps, setSelectedFollowUps] = useState(new Set());
  const lastSelectedIdx = useRef(null);

  const toggleFollowUpSelection = (key, idx, shiftKey, renderedItems) => {
    if (shiftKey && lastSelectedIdx.current !== null) {
      const start = Math.min(lastSelectedIdx.current, idx);
      const end = Math.max(lastSelectedIdx.current, idx);
      const rangeKeys = renderedItems.slice(start, end + 1).map(getRowKey);
      setSelectedFollowUps(prev => {
        const next = new Set(prev);
        rangeKeys.forEach(rangeKey => next.add(rangeKey));
        return next;
      });
      lastSelectedIdx.current = idx;
      return;
    }

    setSelectedFollowUps(prev => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
    lastSelectedIdx.current = idx;
  };

  const { data: ytProducers = [] } = useQuery({
    queryKey: ['youtube-producers'],
    queryFn: () => api.entities.YouTubeProducer.list('-priority', 5000),
  });
  const { data: plProducers = [] } = useQuery({
    queryKey: ['placement-producers'],
    queryFn: () => api.entities.PlacementProducer.list('-priority', 5000),
  });

  // Mark as contacted:
  // - si re_dms === 'no' → saltar a follow up 4 con next_follow_up = +7 días
  // - si no → status = 'contactado', next_follow_up = +1 día
  const markContactedYT = useMutation({
    mutationFn: ({ id, re_dms }) => {
      const today = new Date().toISOString().split('T')[0];
      if (re_dms === 'no') {
        return api.entities.YouTubeProducer.update(id, {
          status: 'follow up 4',
          date_contacted: today,
          last_action: today,
          next_follow_up: addDays(randomDays(5, 10)),
        });
      }
      return api.entities.YouTubeProducer.update(id, {
        status: 'contactado',
        date_contacted: today,
        last_action: today,
        next_follow_up: addDays(1),
      });
    },
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ['youtube-producers'] });
      toast.success(vars.re_dms === 'no' ? 'Re-DMs no → Follow up 4 in 7 days' : 'Marked as contacted');
    },
  });

  const markContactedPL = useMutation({
    mutationFn: ({ id, re_dms }) => {
      const today = new Date().toISOString().split('T')[0];
      if (re_dms === 'no') {
        return api.entities.PlacementProducer.update(id, {
          status: 'follow up 4',
          last_action: today,
          next_follow_up: addDays(randomDays(5, 10)),
        });
      }
      return api.entities.PlacementProducer.update(id, {
        status: 'contactado',
        last_action: today,
        next_follow_up: addDays(1),
      });
    },
    onSuccess: (_, vars) => {
      queryClient.invalidateQueries({ queryKey: ['placement-producers'] });
      toast.success(vars.re_dms === 'no' ? 'Re-DMs no → Follow up 4 in 7 days' : 'Marked as contacted');
    },
  });

  // Advance follow up: siguiente paso, si re_dms=no y ya está en follow up 4+ → archivar
  function getNextFollowUpStatus(currentStatus, re_dms) {
    if (currentStatus === 'contactado') return 'follow up 1';
    if (re_dms === 'no' && (currentStatus === 'follow up 4' || currentStatus === 'follow up 5')) {
      return 'archivado';
    }
    const followUps = ['follow up 1','follow up 2','follow up 3','follow up 4','follow up 5'];
    const idx = followUps.indexOf(currentStatus);
    return idx < followUps.length - 1 ? followUps[idx + 1] : 'archivado';
  }

  const advanceFollowUpYT = useMutation({
    mutationFn: ({ id, currentStatus, re_dms }) => {
      const finalStatus = getNextFollowUpStatus(currentStatus, re_dms);
      const delay = finalStatus === 'archivado' ? null : getRandomOffset(currentStatus);
      return api.entities.YouTubeProducer.update(id, {
        status: finalStatus,
        last_action: new Date().toISOString().split('T')[0],
        next_follow_up: delay != null ? addDays(delay) : null,
      });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['youtube-producers'] }); toast.success('Follow up avanzado'); },
  });

  const advanceFollowUpPL = useMutation({
    mutationFn: ({ id, currentStatus, re_dms }) => {
      const finalStatus = getNextFollowUpStatus(currentStatus, re_dms);
      const delay = finalStatus === 'archivado' ? null : getRandomOffset(currentStatus);
      return api.entities.PlacementProducer.update(id, {
        status: finalStatus,
        last_action: new Date().toISOString().split('T')[0],
        next_follow_up: delay != null ? addDays(delay) : null,
      });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['placement-producers'] }); toast.success('Follow up avanzado'); },
  });

  async function handleRandomDate(clickedProducer, allItems) {
    const clickedKey = `${clickedProducer._type}-${clickedProducer.id}`;
    const targets = selectedFollowUps.size > 0 && selectedFollowUps.has(clickedKey)
      ? allItems.filter(p => selectedFollowUps.has(`${p._type}-${p.id}`))
      : [clickedProducer];
    await Promise.all(targets.map(p => {
      const newDate = addDays(getRandomOffset(p.status));
      if (p._type === 'yt') return api.entities.YouTubeProducer.update(p.id, { next_follow_up: newDate });
      return api.entities.PlacementProducer.update(p.id, { next_follow_up: newDate });
    }));
    queryClient.invalidateQueries({ queryKey: ['youtube-producers'] });
    queryClient.invalidateQueries({ queryKey: ['placement-producers'] });
    toast.success(targets.length > 1 ? `${targets.length} productores reprogramados` : 'Fecha actualizada');
  }

  const today = new Date(); today.setHours(0,0,0,0);

  // Daily DMs: solo por contactar, top por prioridad
  const dailyDMs = [
    ...ytProducers.filter(p => p.status === 'por contactar').map(p => ({ ...p, _type: 'yt' })),
    ...plProducers.filter(p => p.status === 'por contactar').map(p => ({ ...p, _type: 'pl' })),
  ].sort((a, b) => (b.priority || 0) - (a.priority || 0)).slice(0, 10);

  const todayStr = toDateStr(new Date());

  // All producers in follow-up pipeline, sorted oldest first
  const followUps = [
    ...ytProducers.filter(p => p.status?.startsWith('follow up') || p.status === 'contactado').map(p => ({ ...p, _type: 'yt' })),
    ...plProducers.filter(p => p.status?.startsWith('follow up') || p.status === 'contactado').map(p => ({ ...p, _type: 'pl' })),
  ].sort((a, b) => {
    const da = a.next_follow_up ? new Date(a.next_follow_up) : new Date(0);
    const db = b.next_follow_up ? new Date(b.next_follow_up) : new Date(0);
    return da - db;
  });

  const allStatuses = ['contactado', 'follow up 1', 'follow up 2', 'follow up 3', 'follow up 4', 'follow up 5'];
  const statusCounts = {};
  followUps.forEach(p => { statusCounts[p.status] = (statusCounts[p.status] || 0) + 1; });
  const presentStatuses = allStatuses.filter(s => (statusCounts[s] || 0) > 0);

  const followUpsFiltered = statusFilter === 'all' ? followUps : followUps.filter(p => p.status === statusFilter);

  const overdueItems = followUpsFiltered.filter(p => !p.next_follow_up || toDateStr(p.next_follow_up) < todayStr);
  const todayItems = followUpsFiltered.filter(p => p.next_follow_up && toDateStr(p.next_follow_up) === todayStr);
  const upcomingItems = followUpsFiltered.filter(p => p.next_follow_up && toDateStr(p.next_follow_up) > todayStr);
  const dueCount = overdueItems.length + todayItems.length;
  const showOverdue = filter === 'all' || filter === 'overdue';
  const showToday = filter === 'all' || filter === 'today';
  const showUpcoming = filter === 'all' || filter === 'upcoming';
  const visibleFollowUps = useMemo(() => ([
    ...(showOverdue ? overdueItems : []),
    ...(showToday ? todayItems : []),
    ...(showUpcoming ? upcomingItems : []),
  ]), [showOverdue, showToday, showUpcoming, overdueItems, todayItems, upcomingItems]);

  return (
    <div className="space-y-6 sm:space-y-8 md:space-y-10">
      <div>
        <h1 className="text-2xl font-bold text-white">Daily Outreach</h1>
        <p className="text-[#71717a] text-sm mt-1">DMs del día y follow ups pendientes</p>
      </div>

      {/* ── Follow Ups Pendientes ── */}
      <section>
        <div className="mb-3">
          <div className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-semibold text-white">Follow Ups Pendientes</h2>
          </div>
          {(dueCount > 0 || upcomingItems.length > 0) && (
            <div className="flex items-center gap-2 mt-2 sm:mt-0 sm:inline-flex sm:ml-2">
              {dueCount > 0 && (
                <span className="text-xs bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full">
                  {dueCount} due
                </span>
              )}
              {upcomingItems.length > 0 && (
                <span className="text-xs bg-zinc-700/50 text-zinc-400 border border-zinc-700 px-2 py-0.5 rounded-full">
                  {upcomingItems.length} upcoming
                </span>
              )}
            </div>
          )}
        </div>

        {/* Filter tabs — date */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-1.5 mb-2 -mx-3 px-3 sm:mx-0 sm:px-0 sm:overflow-visible">
          {[
            { id: 'all', label: 'All', count: overdueItems.length + todayItems.length + upcomingItems.length },
            { id: 'overdue', label: 'Overdue', count: overdueItems.length },
            { id: 'today', label: 'Today', count: todayItems.length },
            { id: 'upcoming', label: 'Upcoming', count: upcomingItems.length },
          ].map(opt => (
            <button
              key={opt.id}
              onClick={() => setFilter(opt.id)}
              className={`text-xs px-3 py-1 rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                filter === opt.id
                  ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                  : 'bg-transparent text-[#71717a] border-[#27272a] hover:text-white hover:border-[#3f3f46]'
              }`}
            >
              {opt.label}
              {opt.count > 0 && (
                <span className={`text-xs px-1.5 rounded ${filter === opt.id ? 'bg-amber-500/20' : 'bg-[#27272a]'}`}>
                  {opt.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Filter tabs — status */}
        {presentStatuses.length > 1 && (
          <div className="flex flex-wrap items-center gap-1.5 mb-4 -mx-3 px-3 sm:mx-0 sm:px-0">
            {[{ id: 'all', label: 'Todos', count: followUps.length }, ...presentStatuses.map(s => ({
              id: s,
              label: s === 'contactado' ? 'Contactado' : s.replace('follow up ', 'FU '),
              count: statusCounts[s] || 0,
            }))].map(opt => (
              <button
                key={opt.id}
                onClick={() => setStatusFilter(opt.id)}
                className={`text-xs px-3 py-1 rounded-full border transition-colors flex items-center gap-1.5 whitespace-nowrap ${
                  statusFilter === opt.id
                    ? 'bg-zinc-700/60 text-zinc-200 border-zinc-500'
                    : 'bg-transparent text-[#71717a] border-[#27272a] hover:text-zinc-300 hover:border-[#3f3f46]'
                }`}
              >
                {opt.label}
                <span className={`text-xs px-1.5 rounded ${statusFilter === opt.id ? 'bg-zinc-600' : 'bg-[#27272a]'}`}>
                  {opt.count}
                </span>
              </button>
            ))}
          </div>
        )}

        {(overdueItems.length === 0 && todayItems.length === 0 && upcomingItems.length === 0) ? (
          <div className="bg-[#18181b] border border-[#27272a] rounded-xl p-8 text-center text-[#3f3f46]">
            No follow ups pendientes
          </div>
        ) : (() => {
          const renderedItems = visibleFollowUps;
          const renderedKeys = renderedItems.map(getRowKey);
          const renderRow = (p) => {
            const rowKey = getRowKey(p);
            const rowIdx = renderedKeys.indexOf(rowKey);
            const isSelected = selectedFollowUps.has(rowKey);
            return (
            <div key={rowKey} className={`flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 px-3 sm:px-5 py-3 sm:py-3 w-full hover:bg-white/[0.02] ${isSelected ? 'bg-amber-500/5' : ''}`}>
              {/* Checkbox */}
              <input
                type="checkbox"
                checked={isSelected}
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFollowUpSelection(rowKey, rowIdx, e.shiftKey, renderedItems);
                }}
                onChange={() => {}}
                className={`w-4 h-4 flex-shrink-0 rounded-sm cursor-pointer transition-opacity mt-0.5 sm:mt-0 ${isSelected ? 'accent-amber-400 opacity-100' : 'accent-[#3f3f46] opacity-30 hover:opacity-70'}`}
              />
              {/* Row 1: name + instagram + badges (mobile & desktop) */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white sm:truncate">{p.name}</p>
                {p.instagram && (
                  <a href={`https://instagram.com/${p.instagram.replace('@', '')}`}
                    target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1 text-xs text-[#a1a1aa] hover:text-[#e1306c] transition-colors mt-0.5 max-w-[200px] truncate">
                    <Instagram className="w-3 h-3" />{p.instagram.replace('@', '')}
                  </a>
                )}
                <div className="flex items-center gap-1.5 mt-1 flex-wrap">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded border ${
                    p._type === 'yt'
                      ? 'bg-red-500/10 text-red-400 border-red-500/20'
                      : 'bg-purple-500/10 text-purple-400 border-purple-500/20'
                  }`}>
                    {p._type === 'yt' ? 'YouTube' : 'Placement'}
                  </span>
                  <StatusBadge status={p.status} />
                  {p.re_dms === 'no' && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                      Re-DMs: NO
                    </span>
                  )}
                </div>
              </div>

              {/* Row 2 (mobile) / Inline (desktop): date + priority + actions */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-1 sm:gap-2 flex-shrink-0 w-full sm:w-auto">
                <div className="flex-shrink-0">
                  <DateChip dateStr={p.next_follow_up} />
                </div>
                <PriorityBar score={p.priority || 0} max={p._type === 'yt' ? 8 : 10} />
                <div className="flex items-center gap-2 flex-wrap w-full sm:w-auto">
                  <Button size="sm" variant="ghost"
                    onClick={() => setEditProducer(p)}
                    className="text-[#71717a] hover:text-white hover:bg-[#27272a] p-2.5 min-h-[44px] sm:min-h-0 sm:h-auto">
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost"
                    onClick={() => handleRandomDate(p, renderedItems)}
                    className="text-zinc-400 hover:text-zinc-200 hover:bg-zinc-700/50 whitespace-nowrap min-h-[44px] sm:min-h-0 sm:h-auto">
                    <Shuffle className="w-3.5 h-3.5 mr-1" /> Random Date
                  </Button>
                  <Button size="sm" variant="ghost"
                    onClick={() => p._type === 'yt'
                      ? advanceFollowUpYT.mutate({ id: p.id, currentStatus: p.status, re_dms: p.re_dms })
                      : advanceFollowUpPL.mutate({ id: p.id, currentStatus: p.status, re_dms: p.re_dms })}
                    className="text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 whitespace-nowrap min-h-[44px] sm:min-h-0 sm:h-auto">
                    <Check className="w-4 h-4 mr-1" /> Hecho
                  </Button>
                </div>
              </div>
            </div>
          );};


          return (
            <div className="bg-[#18181b] border border-[#27272a] rounded-xl divide-y divide-[#27272a]">
              {showOverdue && overdueItems.length > 0 && (
                <>
                  <GroupHeader label="Overdue" color="border-red-500" textColor="text-red-400" badgeClass="bg-red-500/10 text-red-400 border-red-500/20" count={overdueItems.length} />
                  {overdueItems.map(renderRow)}
                </>
              )}
              {showToday && todayItems.length > 0 && (
                <>
                  <GroupHeader label="Today" color="border-amber-500" textColor="text-amber-400" badgeClass="bg-amber-500/10 text-amber-400 border-amber-500/20" count={todayItems.length} />
                  {todayItems.map(renderRow)}
                </>
              )}
              {showUpcoming && upcomingItems.length > 0 && (
                <>
                  <GroupHeader label="Upcoming" color="border-zinc-500" textColor="text-zinc-400" badgeClass="bg-zinc-700/50 text-zinc-400 border-zinc-700" count={upcomingItems.length} />
                  {upcomingItems.map(renderRow)}
                </>
              )}
              {!showOverdue && !showToday && !showUpcoming && (
                <div className="p-8 text-center text-[#3f3f46]">No hay follow ups para este filtro</div>
              )}
            </div>
          );
        })()}
      </section>

      {/* ── Daily DMs ── */}
      <section>
        <div className="mb-4">
          <div className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-[#3b82f6]" />
            <h2 className="text-lg font-semibold text-white">Daily DMs</h2>
          </div>
          <div className="flex items-center gap-2 mt-2 sm:mt-0 sm:inline-flex sm:ml-2">
            <span className="text-xs bg-[#2563eb]/10 text-[#3b82f6] border border-[#2563eb]/20 px-2 py-0.5 rounded-full">
              Top {dailyDMs.length}
            </span>
          </div>
        </div>

        {dailyDMs.length === 0 ? (
          <div className="bg-[#18181b] border border-[#27272a] rounded-xl p-8 text-center text-[#3f3f46]">
            No hay productores pendientes. ¡Usa Discovery para encontrar nuevos!
          </div>
        ) : (
          <div className="grid gap-3">
            {dailyDMs.map((p, i) => (
              <motion.div key={p.id}
                initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                className="bg-[#18181b] border border-[#27272a] rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 hover:border-[#3f3f46] transition-colors">

                {/* Row 1 (mobile) / Inline (desktop): Ranking + Content */}
                <div className="flex items-start gap-3 sm:gap-4 flex-1 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-[#2563eb]/10 flex items-center justify-center text-sm font-bold text-[#3b82f6] flex-shrink-0">
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-semibold text-white sm:truncate">{p.name}</p>
                      {p.style && <span className={`text-xs ${styleColors[p.style?.split(',')[0]?.trim()] || 'text-zinc-400'}`}>{p.style.split(',')[0].trim()}</span>}
                      {p.re_dms === 'no' && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20">
                          Re-DMs: NO → FU4
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-3 mt-1 flex-wrap">
                      {p.instagram && (
                        <a href={`https://instagram.com/${p.instagram.replace('@','')}`} target="_blank" rel="noopener noreferrer"
                          className="flex items-center gap-1 text-xs text-[#a1a1aa] hover:text-[#e1306c] transition-colors">
                          <Instagram className="w-3 h-3" />{p.instagram}
                        </a>
                      )}
                      {p.email && (
                        <a href={`mailto:${p.email}`} className="flex items-center gap-1 text-xs text-[#71717a] hover:text-[#3b82f6] transition-colors">
                          <Mail className="w-3 h-3" />{p.email}
                        </a>
                      )}
                      <span className="text-xs text-[#3f3f46]">
                        {p.followers_ig ? `${p.followers_ig.toLocaleString()} followers` : ''}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Row 2 (mobile) / Inline (desktop): Priority + Actions */}
                <div className="flex items-center gap-3 sm:gap-2 flex-shrink-0 sm:ml-auto">
                  <PriorityBar score={p.priority || 0} max={p._type === 'yt' ? 8 : 10} />
                  <Button size="sm" variant="ghost"
                    onClick={() => setEditProducer(p)}
                    className="text-[#71717a] hover:text-white hover:bg-[#27272a] p-2.5 min-h-[44px] sm:min-h-0 sm:h-auto">
                    <Pencil className="w-3.5 h-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost"
                    onClick={() => p._type === 'yt'
                      ? markContactedYT.mutate({ id: p.id, re_dms: p.re_dms })
                      : markContactedPL.mutate({ id: p.id, re_dms: p.re_dms })}
                    className="text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 whitespace-nowrap h-11 sm:h-auto">
                    <Check className="w-4 h-4 mr-1" /> Enviado
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>

      <ProducerProfile
        key={editProducer ? `${editProducer._type}-${editProducer.id}` : 'none'}
        producer={editProducer}
        type={getProfileType(editProducer?._type)}
        onClose={() => setEditProducer(null)}
        onSave={async (data) => {
          const payload = buildProducerPayload(data);
          if (editProducer?._type === 'yt') {
            await api.entities.YouTubeProducer.update(editProducer.id, payload);
          } else {
            await api.entities.PlacementProducer.update(editProducer.id, payload);
          }
          queryClient.invalidateQueries({ queryKey: ['youtube-producers'] });
          queryClient.invalidateQueries({ queryKey: ['placement-producers'] });
          setEditProducer(null);
        }}
        onDelete={async (id) => {
          if (editProducer?._type === 'yt') {
            await api.entities.YouTubeProducer.delete(id);
          } else {
            await api.entities.PlacementProducer.delete(id);
          }
          queryClient.invalidateQueries({ queryKey: ['youtube-producers'] });
          queryClient.invalidateQueries({ queryKey: ['placement-producers'] });
          setEditProducer(null);
        }}
      />
    </div>
  );
}