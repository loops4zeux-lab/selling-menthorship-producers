import React, { useState, useEffect, useRef, useCallback } from 'react';
import Sidebar from './Sidebar';
import BottomNav from './BottomNav';
import { cn } from '@/lib/utils';
import { Menu, RefreshCw } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';

const SYNC_INTERVAL_MS = 15 * 60 * 1000;
const STORAGE_KEY = 'notion_last_sync';

function formatAgo(date) {
  const mins = Math.round((Date.now() - date.getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  return `${Math.round(mins / 60)}h ago`;
}

function SyncDot({ status, lastSync, onSync }) {
  const dotColor = {
    idle:    'bg-zinc-600',
    syncing: 'bg-amber-400 animate-pulse',
    ok:      'bg-emerald-500',
    error:   'bg-red-500',
  }[status];

  const label = status === 'syncing' ? 'Syncing…'
    : lastSync ? `Notion · ${formatAgo(lastSync)}`
    : 'Notion sync';

  return (
    <button
      onClick={() => onSync(true)}
      disabled={status === 'syncing'}
      title={status === 'error' ? 'Sync failed — click to retry' : 'Click to force full sync'}
      className="flex items-center gap-1.5 px-2 py-1 rounded-md text-[11px] text-[#71717a] hover:text-white hover:bg-[#27272a] transition-colors disabled:cursor-not-allowed"
    >
      <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${dotColor}`} />
      {status === 'syncing' && <RefreshCw className="w-3 h-3 animate-spin" />}
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}

export default function AppLayout({ children }) {
  const [collapsed, setCollapsed]   = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [syncStatus, setSyncStatus] = useState('idle');
  const [lastSync, setLastSync]     = useState(() => {
    if (typeof window === 'undefined') return null;
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? new Date(stored) : null;
  });
  const timerRef    = useRef(null);
  const queryClient = useQueryClient();

  const runSync = useCallback(async (manual = false) => {
    setSyncStatus('syncing');
    try {
      // Manual sync: no time filter → processes all records
      // Auto sync: incremental → only records changed since last sync
      const body = manual ? {} : { lastSyncTime: lastSync?.toISOString() ?? null };
      const res = await fetch('/api/sync/notion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Sync failed');
      }
      const data = await res.json();
      const now = new Date();
      setLastSync(now);
      localStorage.setItem(STORAGE_KEY, now.toISOString());
      setSyncStatus('ok');

      // Refresh UI if Notion had changes
      if (data.stats?.updated_in_app > 0 || data.stats?.created_in_app > 0) {
        queryClient.invalidateQueries({ queryKey: ['placement-producers'] });
      }
    } catch (err) {
      console.error('[notion-sync]', err.message);
      setSyncStatus('error');
    }
  }, [queryClient]);

  useEffect(() => {
    const timeSinceLast = lastSync ? Date.now() - lastSync.getTime() : Infinity;
    const delay = timeSinceLast >= SYNC_INTERVAL_MS ? 0 : SYNC_INTERVAL_MS - timeSinceLast;

    timerRef.current = setTimeout(() => {
      runSync();
      timerRef.current = setInterval(runSync, SYNC_INTERVAL_MS);
    }, delay);

    return () => {
      clearTimeout(timerRef.current);
      clearInterval(timerRef.current);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const syncProps = { status: syncStatus, lastSync, onSync: runSync };

  return (
    <div className="min-h-screen bg-[#0f0f10]">
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-black/60 md:hidden" onClick={() => setMobileOpen(false)} />
      )}

      <Sidebar
        collapsed={collapsed}
        onToggle={() => setCollapsed(!collapsed)}
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
      />

      <main className={cn(
        "transition-all duration-300 ease-in-out min-h-screen",
        "ml-0 md:ml-[240px]",
        collapsed && "md:ml-[68px]"
      )}>
        {/* Mobile header */}
        <div className="flex items-center justify-between px-4 h-14 border-b border-[#27272a] bg-[#18181b] md:hidden">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileOpen(true)} className="text-[#a1a1aa] hover:text-white transition-colors">
              <Menu className="w-5 h-5" />
            </button>
            <span className="font-semibold text-[15px] text-white tracking-tight">Producer Radar</span>
          </div>
          <SyncDot {...syncProps} />
        </div>

        {/* Desktop sync indicator */}
        <div className="hidden md:flex justify-end px-8 pt-3">
          <SyncDot {...syncProps} />
        </div>

        <div className="p-4 md:p-8 md:pt-4 pb-[calc(3.5rem+env(safe-area-inset-bottom))] md:pb-8">
          {children}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}
