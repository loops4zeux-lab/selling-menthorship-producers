import React from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import { LayoutDashboard, Users, Youtube, Music2, Radar } from 'lucide-react';

const items = [
  { path: '/Dashboard',          label: 'Dashboard', icon: LayoutDashboard },
  { path: '/DailyContacts',      label: 'Outreach',  icon: Users },
  { path: '/Discovery',          label: 'Discovery', icon: Radar },
  { path: '/YouTubeProducers',   label: 'YouTube',   icon: Youtube },
  { path: '/PlacementProducers', label: 'Placements',icon: Music2 },
];

export default function BottomNav() {
  const { pathname } = useRouter();

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-[#18181b] border-t border-[#27272a]"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="flex items-stretch h-14">
        {items.map(({ path, label, icon: Icon }) => {
          const active = pathname === path || pathname.startsWith(path + '/');
          return (
            <Link
              key={path}
              href={path}
              className={`flex flex-1 flex-col items-center justify-center gap-0.5 transition-colors active:bg-white/5 ${
                active ? 'text-[#3b82f6]' : 'text-[#52525b]'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {active && (
                  <span className="absolute -top-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#3b82f6]" />
                )}
              </div>
              <span className="text-[10px] font-medium leading-none">{label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
