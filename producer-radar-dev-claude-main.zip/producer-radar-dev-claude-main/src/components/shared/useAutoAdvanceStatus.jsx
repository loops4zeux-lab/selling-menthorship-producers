export function useAutoAdvanceStatus() {}
