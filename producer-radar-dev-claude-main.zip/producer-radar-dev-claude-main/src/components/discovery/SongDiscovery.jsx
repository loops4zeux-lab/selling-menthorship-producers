import React, { useState, useRef, useEffect } from 'react';
import { api } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Headphones, Play, Pause, SkipForward, Heart, Loader2, Music } from 'lucide-react';
import { toast } from 'sonner';

function fmtTime(secs) {
  const s = Math.floor(secs || 0);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

export default function SongDiscovery() {
  const [phase, setPhase] = useState('idle'); // idle | loading | playing | adding | done
  const [styleQuery, setStyleQuery] = useState('');
  const [tracks, setTracks] = useState([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [added, setAdded] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(30);
  const audioRef = useRef(null);

  const currentTrack = tracks[currentIdx];

  useEffect(() => {
    if (phase !== 'playing') return;
    const track = tracks[currentIdx];
    if (!track?.previewUrl) return;
    const audio = audioRef.current;
    if (!audio) return;
    audio.src = track.previewUrl;
    audio.load();
    setProgress(0);
    setIsPlaying(false);
    audio.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
  }, [currentIdx, phase]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = '';
      }
    };
  }, []);

  function togglePlay() {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  }

  function handleSeek(e) {
    const audio = audioRef.current;
    if (!audio?.duration) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    audio.currentTime = ratio * audio.duration;
    setProgress(ratio);
  }

  function goNext() {
    const nextIdx = currentIdx + 1;
    if (nextIdx >= tracks.length) {
      setPhase('done');
    } else {
      setCurrentIdx(nextIdx);
      setPhase('playing');
    }
  }

  async function fetchTracks(query) {
    setPhase('loading');
    try {
      const res = await fetch('/api/spotify/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Error buscando canciones');
      if (!data.tracks?.length) {
        toast.error('No se encontraron canciones con preview. Prueba otro estilo.');
        setPhase('idle');
        return;
      }
      setTracks(data.tracks);
      setCurrentIdx(0);
      setAdded(0);
      setPhase('playing');
    } catch (err) {
      toast.error(err.message);
      setPhase('idle');
    }
  }

  async function handleLike() {
    if (!currentTrack || phase === 'adding') return;
    const audio = audioRef.current;
    if (audio) { audio.pause(); setIsPlaying(false); }
    setPhase('adding');

    try {
      const res = await fetch('/api/discovery/song-producer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: currentTrack.title, artist: currentTrack.artist }),
      });
      const data = await res.json();
      const producers = data.producers || [];

      if (producers.length === 0) {
        toast.info('No se encontró productor en Genius para esta canción');
      } else {
        for (const p of producers) {
          if (p.isDuplicate) {
            toast.info(`${p.name} ya está en la DB`);
          } else {
            try {
              await api.entities.PlacementProducer.create({
                name: p.name,
                instagram: p.instagram || '',
                song: p.song || currentTrack.title,
                artist: p.artist || currentTrack.artist,
                placements: p.placements || '',
                style: p.style || '',
                source: 'Song Discovery',
                status: 'por contactar',
              });
              toast.success(`Añadido: ${p.name}`);
              setAdded(n => n + 1);
            } catch {
              toast.error(`Error guardando ${p.name}`);
            }
          }
        }
      }
    } catch (err) {
      toast.error('Error: ' + err.message);
    }

    goNext();
  }

  function handleSkip() {
    const audio = audioRef.current;
    if (audio) { audio.pause(); setIsPlaying(false); }
    goNext();
  }

  // ── idle ──
  if (phase === 'idle') {
    return (
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Headphones className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-semibold text-white">Song Discovery</h2>
        </div>
        <div className="bg-[#18181b] border border-[#27272a] rounded-xl p-6">
          <p className="text-sm text-[#71717a] mb-4">
            Busca canciones por estilo y añade sus productores automáticamente desde Genius.
          </p>
          <div className="flex gap-3">
            <input
              type="text"
              value={styleQuery}
              onChange={e => setStyleQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && styleQuery.trim() && fetchTracks(styleQuery)}
              placeholder="trap with guitars, emo trap piano, melodic rap sad…"
              className="flex-1 bg-[#27272a] border border-[#3f3f46] rounded-lg px-4 py-2.5 text-sm text-white placeholder:text-[#52525b] focus:outline-none focus:border-emerald-500/50 transition-colors"
            />
            <Button
              onClick={() => fetchTracks(styleQuery)}
              disabled={!styleQuery.trim()}
              className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 px-5"
            >
              Empezar
            </Button>
          </div>
        </div>
      </section>
    );
  }

  // ── loading ──
  if (phase === 'loading') {
    return (
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Headphones className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-semibold text-white">Song Discovery</h2>
        </div>
        <div className="bg-[#18181b] border border-[#27272a] rounded-xl p-12 flex flex-col items-center gap-3 text-[#71717a]">
          <Loader2 className="w-6 h-6 animate-spin text-emerald-400" />
          <p className="text-sm">Buscando canciones de &quot;{styleQuery}&quot;…</p>
        </div>
      </section>
    );
  }

  // ── done ──
  if (phase === 'done') {
    return (
      <section>
        <div className="flex items-center gap-2 mb-4">
          <Headphones className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-semibold text-white">Song Discovery</h2>
        </div>
        <div className="bg-[#18181b] border border-[#27272a] rounded-xl p-10 flex flex-col items-center gap-4 text-center">
          <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center">
            <Music className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <p className="text-white font-semibold">
              {added} productor{added !== 1 ? 'es' : ''} añadido{added !== 1 ? 's' : ''}
            </p>
            <p className="text-sm text-[#71717a] mt-1">
              Has repasado {tracks.length} canciones de &quot;{styleQuery}&quot;
            </p>
          </div>
          <div className="flex gap-3 mt-2">
            <Button
              onClick={() => fetchTracks(styleQuery)}
              className="bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25"
            >
              Cargar más canciones
            </Button>
            <Button
              variant="ghost"
              onClick={() => { setPhase('idle'); setStyleQuery(''); }}
              className="text-[#71717a] hover:text-white hover:bg-[#27272a]"
            >
              Cambiar estilo
            </Button>
          </div>
        </div>
      </section>
    );
  }

  // ── playing / adding ──
  const track = currentTrack;
  const isAdding = phase === 'adding';

  return (
    <section>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Headphones className="w-5 h-5 text-emerald-400" />
          <h2 className="text-lg font-semibold text-white">Song Discovery</h2>
        </div>
        <div className="flex items-center gap-3">
          {added > 0 && (
            <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
              {added} añadidos
            </span>
          )}
          <span className="text-xs text-[#52525b]">{currentIdx + 1} / {tracks.length}</span>
        </div>
      </div>

      <audio
        ref={audioRef}
        onTimeUpdate={() => {
          const audio = audioRef.current;
          if (audio?.duration) setProgress(audio.currentTime / audio.duration);
        }}
        onLoadedMetadata={() => {
          if (audioRef.current) setDuration(audioRef.current.duration || 30);
        }}
        onEnded={() => setIsPlaying(false)}
      />

      <div className="bg-[#18181b] border border-[#27272a] rounded-xl overflow-hidden">
        {/* Header: blurred art + track info */}
        <div className="relative h-36 flex items-end overflow-hidden">
          {track?.albumArt ? (
            <img
              src={track.albumArt}
              alt=""
              className="absolute inset-0 w-full h-full object-cover opacity-25 scale-110 blur-sm"
            />
          ) : (
            <div className="absolute inset-0 bg-[#27272a]" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#18181b] via-[#18181b]/60 to-transparent" />
          <div className="relative flex items-end gap-4 px-5 pb-4 w-full">
            {track?.albumArt ? (
              <img
                src={track.albumArt}
                alt={track.album}
                className="w-14 h-14 rounded-lg shadow-xl border border-white/10 flex-shrink-0"
              />
            ) : (
              <div className="w-14 h-14 rounded-lg bg-[#27272a] flex items-center justify-center flex-shrink-0">
                <Music className="w-6 h-6 text-[#52525b]" />
              </div>
            )}
            <div className="min-w-0">
              <p className="text-white font-semibold text-base truncate">{track?.title}</p>
              <p className="text-[#71717a] text-sm truncate">{track?.artist}</p>
            </div>
          </div>
        </div>

        {/* Player + actions */}
        <div className="px-5 py-4 space-y-4">
          {/* Progress bar */}
          <div>
            <div
              className="h-1.5 bg-[#27272a] rounded-full cursor-pointer relative overflow-hidden"
              onClick={handleSeek}
            >
              <div
                className="absolute left-0 top-0 h-full bg-emerald-500 rounded-full"
                style={{ width: `${progress * 100}%`, transition: 'width 0.1s linear' }}
              />
            </div>
            <div className="flex items-center justify-between mt-1.5">
              <button
                onClick={togglePlay}
                disabled={isAdding || !track?.previewUrl}
                className="flex items-center gap-1.5 text-xs text-[#71717a] hover:text-white transition-colors disabled:opacity-40"
              >
                {isPlaying
                  ? <Pause className="w-3.5 h-3.5" />
                  : <Play className="w-3.5 h-3.5" />}
                {fmtTime(progress * duration)} / {fmtTime(duration)}
              </button>
              {!track?.previewUrl && (
                <span className="text-xs text-[#3f3f46]">Sin preview disponible</span>
              )}
            </div>
          </div>

          {/* Skip / Like */}
          <div className="flex gap-3">
            <Button
              onClick={handleSkip}
              disabled={isAdding}
              variant="ghost"
              className="flex-1 border border-[#27272a] text-[#71717a] hover:text-white hover:bg-[#27272a] h-11"
            >
              <SkipForward className="w-4 h-4 mr-2" /> Skip
            </Button>
            <Button
              onClick={handleLike}
              disabled={isAdding}
              className="flex-1 bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/25 h-11"
            >
              {isAdding ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Buscando…</>
              ) : (
                <><Heart className="w-4 h-4 mr-2" /> Add Producer</>
              )}
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
