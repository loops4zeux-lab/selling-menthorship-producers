/**
 * Reset Notion sync: archives all existing Notion pages, then pushes all
 * app records to Notion as fresh pages and links them back.
 *
 * Run: node --env-file=.env scripts/reset-notion-sync.mjs
 */

import pg from 'pg';
const { Pool } = pg;

const TOKEN  = process.env.NOTION_TOKEN;
const DB_ID  = process.env.NOTION_DATABASE_ID;
const pool   = new Pool({ connectionString: process.env.DATABASE_URL });

const HDR = {
  'Authorization': `Bearer ${TOKEN}`,
  'Notion-Version': '2022-06-28',
  'Content-Type': 'application/json',
};

async function notionReq(method, path, body) {
  const res = await fetch(`https://api.notion.com/v1${path}`, {
    method, headers: HDR,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`${res.status} ${JSON.stringify(data).slice(0, 200)}`);
  return data;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const STATUS_MAP = {
  'por contactar':'Contactar','contactado':'Contactado/48h',
  'follow up 1':'Follow up 1 - mención','follow up 2':'Follow up 2 - loops',
  'follow up 3':'Follow up 3 - msg','follow up 4':'Follow up 4 - Comment',
  'follow up 5':'Follow up 5 - comment','connection':'connection',
  'eliminado':'Eliminado','archivado':'Archivado (para el futuro)',
};
const STARS = {1:'⭐',2:'⭐⭐',3:'⭐⭐⭐',4:'⭐️⭐️⭐️⭐️',5:'⭐️⭐️⭐️⭐️⭐️'};
const tags  = str => str ? str.split(',').map(t=>t.trim()).filter(Boolean).map(name=>({name})) : [];

function toProps(p) {
  const props = {
    'Nombre':            { title: [{ text: { content: p.name || '' } }] },
    'Instagram':         { url: p.instagram || null },
    'Mail':              { phone_number: p.email || null },
    'phone':             { phone_number: p.phone || null },
    'Style':             { multi_select: tags(p.style) },
    'Send':              { multi_select: tags(p.que_enviar) },
    'Donde enviar':      { multi_select: tags(p.donde_enviar) },
    'Prospection':       { multi_select: tags(p.artist) },
    'Credits':           { multi_select: tags(p.highlights_placements) },
    'notas':             { rich_text: p.notes ? [{ text: { content: p.notes } }] : [] },
    'Top / objetivo':    { checkbox: p.favorite ?? false },
    'Próximo follow up': { date: p.next_follow_up ? { start: p.next_follow_up } : null },
    'Ultima Acción':     { date: p.last_action    ? { start: p.last_action }    : null },
    'Estado':            { select: STATUS_MAP[p.status] ? { name: STATUS_MAP[p.status] } : null },
    'Redms?':            { select: ({yes:'Yes',no:'no'})[p.re_dms] ? { name: ({yes:'Yes',no:'no'})[p.re_dms] } : null },
    'Relación':          { select: STARS[p.relacion] ? { name: STARS[p.relacion] } : null },
  };
  if (p.priority != null) props['Muso popularity'] = { number: p.priority };
  return props;
}

// ─── Step 1: Archive all existing Notion pages ────────────────────────────────

async function archiveAll() {
  console.log('\n── Step 1: Archiving all existing Notion pages…');
  let cursor, total = 0;
  do {
    const body = { page_size: 100 };
    if (cursor) body.start_cursor = cursor;
    const res = await notionReq('POST', `/databases/${DB_ID}/query`, body);
    const active = res.results.filter(p => !p.archived);
    for (const page of active) {
      await notionReq('PATCH', `/pages/${page.id}`, { archived: true });
      process.stdout.write('·');
      total++;
    }
    cursor = res.has_more ? res.next_cursor : null;
  } while (cursor);
  console.log(`\n   Archived: ${total} pages`);
}

// ─── Step 2: Reset notion_id on all app records ───────────────────────────────

async function resetNotionIds() {
  console.log('\n── Step 2: Resetting notion_id on all app records…');
  const { rowCount } = await pool.query('UPDATE "PlacementProducer" SET notion_id = NULL');
  console.log(`   Reset: ${rowCount} records`);
}

// ─── Step 3: Push all app records to Notion ───────────────────────────────────

async function pushAll() {
  console.log('\n── Step 3: Pushing app records to Notion…');
  const { rows } = await pool.query('SELECT * FROM "PlacementProducer" ORDER BY created_date ASC');
  console.log(`   ${rows.length} records to push`);

  let ok = 0, errors = 0;
  for (const p of rows) {
    try {
      const page = await notionReq('POST', '/pages', {
        parent: { database_id: DB_ID },
        properties: toProps(p),
      });
      await pool.query('UPDATE "PlacementProducer" SET notion_id=$1 WHERE id=$2', [page.id, p.id]);
      ok++;
      if (ok % 50 === 0) process.stdout.write(`\n   ${ok}/${rows.length}…`);
      else process.stdout.write('+');
    } catch (err) {
      errors++;
      process.stdout.write('✗');
    }
  }
  console.log(`\n   Done. Created: ${ok}  Errors: ${errors}`);
}

// ─── Main ──────────────────────────────────────────────────────────────────────

(async () => {
  if (!TOKEN || !DB_ID) { console.error('Missing NOTION_TOKEN or NOTION_DATABASE_ID'); process.exit(1); }

  console.log('Starting full Notion reset…');
  await archiveAll();
  await resetNotionIds();
  await pushAll();

  const { rows: [{ count }] } = await pool.query('SELECT COUNT(*) FROM "PlacementProducer"');
  await pool.end();
  console.log(`\n✓ Done. App records: ${count}`);
})();
