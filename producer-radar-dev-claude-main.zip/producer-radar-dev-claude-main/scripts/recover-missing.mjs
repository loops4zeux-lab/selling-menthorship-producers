/**
 * One-time script: recovers contacts that exist in Notion but not in the app.
 * Uses Instagram as the ONLY deduplication key.
 * Run: node --env-file=.env scripts/recover-missing.mjs
 */

import pg from 'pg';
const { Pool } = pg;

const NOTION_TOKEN = process.env.NOTION_TOKEN;
const NOTION_DB_ID = process.env.NOTION_DATABASE_ID;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const HDR = {
  'Authorization': `Bearer ${NOTION_TOKEN}`,
  'Notion-Version': '2022-06-28',
  'Content-Type': 'application/json',
};

function normalizeIG(ig) {
  if (!ig) return null;
  return ig.toLowerCase()
    .replace(/^https?:\/\/(www\.)?instagram\.com\//i, '')
    .replace(/^@/, '').replace(/\/$/, '').trim() || null;
}

async function fetchAll() {
  const pages = [];
  let cursor;
  do {
    const body = { page_size: 100 };
    if (cursor) body.start_cursor = cursor;
    const res = await fetch(`https://api.notion.com/v1/databases/${NOTION_DB_ID}/query`, {
      method: 'POST', headers: HDR, body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(JSON.stringify(data));
    pages.push(...data.results.filter(p => !p.archived));
    cursor = data.has_more ? data.next_cursor : null;
  } while (cursor);
  return pages;
}

function getIG(page) {
  return normalizeIG(page.properties['Instagram']?.url);
}

function getName(page) {
  return (page.properties['Nombre']?.title ?? [])
    .map(t => t.plain_text || t.text?.content || '').join('').trim();
}

const STATUS_MAP = {
  'Contactar':'por contactar','Contactado/48h':'contactado',
  'Follow up 1 - mención':'follow up 1','Follow up 2 - loops':'follow up 2',
  'Follow up 3 - msg':'follow up 3','Follow up 4 - Comment':'follow up 4',
  'Follow up 5 - comment':'follow up 5','connection':'connection',
  'Eliminado':'eliminado','Archivado (para el futuro)':'archivado','no response':'archivado',
};
const STARS = {'⭐':1,'⭐⭐':2,'⭐⭐⭐':3,'⭐️⭐️⭐️⭐️':4,'⭐️⭐️⭐️⭐️⭐️':5};
const joinTags = ms => ms?.length ? ms.map(t=>t.name).join(', ') : null;
const plainText = rt => rt?.length ? rt.map(t=>t.plain_text||t.text?.content||'').join('')||null : null;

function pageToFields(page) {
  const p = page.properties;
  return {
    notion_id:             page.id,
    name:                  getName(page),
    status:                STATUS_MAP[p['Estado']?.select?.name] ?? 'por contactar',
    instagram:             p['Instagram']?.url || null,
    email:                 p['Mail']?.phone_number || null,
    phone:                 p['phone']?.phone_number || null,
    re_dms:                p['Redms?']?.select?.name === 'Yes' ? 'yes' : p['Redms?']?.select?.name === 'no' ? 'no' : 'unknown',
    next_follow_up:        p['Próximo follow up']?.date?.start || null,
    last_action:           p['Ultima Acción']?.date?.start || null,
    style:                 joinTags(p['Style']?.multi_select),
    que_enviar:            joinTags(p['Send']?.multi_select),
    donde_enviar:          joinTags(p['Donde enviar']?.multi_select),
    priority:              p['Muso popularity']?.number ?? 5,
    artist:                joinTags(p['Prospection']?.multi_select),
    highlights_placements: joinTags(p['Credits']?.multi_select),
    relacion:              STARS[p['Relación']?.select?.name] ?? null,
    notes:                 plainText(p['notas']?.rich_text),
    favorite:              p['Top / objetivo']?.checkbox ?? false,
    source:                'Notion',
  };
}

(async () => {
  console.log('Fetching app records…');
  const { rows: appRows } = await pool.query(
    'SELECT id, instagram, notion_id FROM "PlacementProducer"'
  );
  const appByIG       = new Map(appRows.filter(r=>r.instagram).map(r=>[normalizeIG(r.instagram), r]));
  const appByNotionId = new Map(appRows.filter(r=>r.notion_id).map(r=>[r.notion_id, r]));
  console.log(`  → ${appRows.length} records in app`);

  console.log('Fetching Notion pages…');
  const pages = await fetchAll();
  console.log(`  → ${pages.length} pages in Notion`);

  let linked = 0, created = 0, skipped = 0, errors = 0;

  for (const page of pages) {
    const igKey = getIG(page);
    const match = appByNotionId.get(page.id) ?? (igKey ? appByIG.get(igKey) : null);

    if (match) {
      // Link notion_id if missing
      if (!match.notion_id) {
        await pool.query('UPDATE "PlacementProducer" SET notion_id=$1 WHERE id=$2', [page.id, match.id]);
        linked++;
      }
    } else if (igKey) {
      // Genuinely missing contact — create it
      const f = pageToFields(page);
      try {
        await pool.query(`
          INSERT INTO "PlacementProducer"
            (id, name, status, instagram, email, phone, re_dms, next_follow_up, last_action,
             style, que_enviar, donde_enviar, priority, artist, highlights_placements,
             relacion, notes, favorite, source, notion_id, created_date, updated_at)
          VALUES
            (gen_random_uuid(), $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,now(),now())
        `, [f.name,f.status,f.instagram,f.email,f.phone,f.re_dms,f.next_follow_up,f.last_action,
            f.style,f.que_enviar,f.donde_enviar,f.priority,f.artist,f.highlights_placements,
            f.relacion,f.notes,f.favorite,f.source,f.notion_id]);
        appByIG.set(igKey, { notion_id: page.id }); // prevent double-create in same run
        process.stdout.write('+');
        created++;
      } catch (err) {
        process.stdout.write('✗');
        errors++;
      }
    } else {
      skipped++;
    }
  }

  const { rows: [{ count }] } = await pool.query('SELECT COUNT(*) FROM "PlacementProducer"');
  await pool.end();
  console.log(`\n\nDone. Linked: ${linked}  Created: ${created}  Skipped (no IG): ${skipped}  Errors: ${errors}`);
  console.log('Total records:', count);
})();
