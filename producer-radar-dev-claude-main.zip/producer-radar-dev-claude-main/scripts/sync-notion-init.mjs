/**
 * Initial sync: pushes all PlacementProducer records from the app DB to Notion.
 * Run with: node --env-file=.env scripts/sync-notion-init.mjs
 */

import pg from 'pg';
const { Pool } = pg;

const NOTION_TOKEN = process.env.NOTION_TOKEN;
const NOTION_DB_ID = process.env.NOTION_DATABASE_ID;
const DATABASE_URL = process.env.DATABASE_URL;

if (!NOTION_TOKEN || !NOTION_DB_ID || !DATABASE_URL) {
  console.error('Missing env vars');
  process.exit(1);
}

const HEADERS = {
  'Authorization': `Bearer ${NOTION_TOKEN}`,
  'Notion-Version': '2022-06-28',
  'Content-Type': 'application/json',
};

// ─── Notion REST helpers ───────────────────────────────────────────────────────

async function notionFetch(method, path, body) {
  const res = await fetch(`https://api.notion.com/v1${path}`, {
    method,
    headers: HEADERS,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Notion ${method} ${path} → ${res.status}: ${JSON.stringify(data)}`);
  return data;
}

async function fetchAllPages() {
  const pages = [];
  let cursor;
  do {
    const body = { page_size: 100 };
    if (cursor) body.start_cursor = cursor;
    const res = await notionFetch('POST', `/databases/${NOTION_DB_ID}/query`, body);
    pages.push(...res.results.filter(p => !p.archived));
    cursor = res.has_more ? res.next_cursor : null;
  } while (cursor);
  return pages;
}

async function createPage(properties) {
  return notionFetch('POST', '/pages', { parent: { database_id: NOTION_DB_ID }, properties });
}

async function updatePage(pageId, properties) {
  return notionFetch('PATCH', `/pages/${pageId}`, { properties });
}

// ─── Mappings ──────────────────────────────────────────────────────────────────

const STATUS_TO_NOTION = {
  'por contactar': 'Contactar',
  'contactado':    'Contactado/48h',
  'follow up 1':   'Follow up 1 - mención',
  'follow up 2':   'Follow up 2 - loops',
  'follow up 3':   'Follow up 3 - msg',
  'follow up 4':   'Follow up 4 - Comment',
  'follow up 5':   'Follow up 5 - comment',
  'connection':    'connection',
  'eliminado':     'Eliminado',
  'archivado':     'Archivado (para el futuro)',
};

const RELACION_TO_STARS = { 1:'⭐', 2:'⭐⭐', 3:'⭐⭐⭐', 4:'⭐️⭐️⭐️⭐️', 5:'⭐️⭐️⭐️⭐️⭐️' };

function tags(str) {
  if (!str) return [];
  return str.split(',').map(t => t.trim()).filter(Boolean).map(name => ({ name }));
}

function toProps(p) {
  const props = {
    'Nombre':            { title: [{ text: { content: p.name || '' } }] },
    'Instagram':         { url: p.instagram || null },
    'Mail':              { phone_number: p.email || null },
    'phone':             { phone_number: p.phone || null },
    'Style':             { multi_select: tags(p.style) },
    'Send':              { multi_select: tags(p.que_enviar) },
    'Donde enviar':      { multi_select: tags(p.donde_enviar) },
    'Prospection':       { multi_select: tags(p.artist) },
    'Credits':           { multi_select: tags(p.highlights_placements) },
    'notas':             { rich_text: p.notes ? [{ text: { content: p.notes } }] : [] },
    'Top / objetivo':    { checkbox: p.favorite ?? false },
    'Próximo follow up': { date: p.next_follow_up ? { start: p.next_follow_up } : null },
    'Ultima Acción':     { date: p.last_action    ? { start: p.last_action }    : null },
  };

  const ns = STATUS_TO_NOTION[p.status];
  if (ns) props['Estado'] = { select: { name: ns } };

  const rdMap = { yes: 'Yes', no: 'no' };
  if (rdMap[p.re_dms]) props['Redms?'] = { select: { name: rdMap[p.re_dms] } };

  if (p.priority != null) props['Muso popularity'] = { number: p.priority };

  const stars = RELACION_TO_STARS[p.relacion];
  if (stars) props['Relación'] = { select: { name: stars } };

  return props;
}

function notionName(page) {
  return (page.properties['Nombre']?.title ?? [])
    .map(t => t.plain_text || t.text?.content || '').join('').toLowerCase().trim();
}

// ─── Main ──────────────────────────────────────────────────────────────────────

const pool = new Pool({ connectionString: DATABASE_URL });

(async () => {
  console.log('Fetching PlacementProducer records from DB…');
  const { rows: producers } = await pool.query('SELECT * FROM "PlacementProducer" ORDER BY created_date ASC');
  console.log(`  → ${producers.length} records`);

  console.log('Fetching existing Notion pages…');
  const notionPages = await fetchAllPages();
  console.log(`  → ${notionPages.length} pages in Notion`);

  const byName = new Map(notionPages.map(p => [notionName(p), p]));

  let created = 0, updated = 0, errors = 0;
  console.log('\nSyncing… (· updated, + created, ✗ error)');

  for (const producer of producers) {
    const key = (producer.name || '').toLowerCase().trim();
    const existing = byName.get(key);
    try {
      if (existing) {
        await updatePage(existing.id, toProps(producer));
        updated++;
        process.stdout.write('·');
      } else {
        await createPage(toProps(producer));
        created++;
        process.stdout.write('+');
      }
    } catch (err) {
      errors++;
      process.stdout.write('✗');
      console.error(`\n  "${producer.name}": ${err.message}`);
    }
  }

  await pool.end();
  console.log(`\n\nDone! Created: ${created}  Updated: ${updated}  Errors: ${errors}`);
})();
