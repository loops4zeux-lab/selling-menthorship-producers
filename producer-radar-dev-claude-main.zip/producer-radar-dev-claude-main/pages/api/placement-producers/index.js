import { prisma } from '@/lib/db';
import { appToNotionProps } from '@/lib/notion-sync';

function parseSort(sortParam) {
  if (!sortParam) return { created_date: 'desc' };
  const desc = sortParam.startsWith('-');
  const field = desc ? sortParam.slice(1) : sortParam;
  return { [field]: desc ? 'desc' : 'asc' };
}

export default async function handler(req, res) {
  if (req.method === 'GET') {
    try {
      const { sort, limit } = req.query;
      const producers = await prisma.placementProducer.findMany({
        orderBy: parseSort(sort),
        take: limit ? parseInt(limit) : undefined,
      });
      return res.status(200).json(producers);
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  }

  if (req.method === 'POST') {
    try {
      const { re_dms = null, ...rest } = req.body;
      const producer = await prisma.placementProducer.create({ data: { ...rest, re_dms } });
      // Create in Notion and link back
      const token = process.env.NOTION_TOKEN;
      const dbId  = process.env.NOTION_DATABASE_ID;
      if (token && dbId) {
        fetch('https://api.notion.com/v1/pages', {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${token}`, 'Notion-Version': '2022-06-28', 'Content-Type': 'application/json' },
          body: JSON.stringify({ parent: { database_id: dbId }, properties: appToNotionProps(producer) }),
        }).then(r => r.json()).then(data => {
          if (data.id) prisma.placementProducer.update({ where: { id: producer.id }, data: { notion_id: data.id } }).catch(() => {});
        }).catch(() => {});
      }
      return res.status(201).json(producer);
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  }

  if (req.method === 'DELETE') {
    try {
      await prisma.placementProducer.deleteMany({});
      return res.status(200).json({ deleted: true });
    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  }

  res.status(405).end();
}
