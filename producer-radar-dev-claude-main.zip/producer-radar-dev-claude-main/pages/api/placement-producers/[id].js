import { prisma } from '@/lib/db';
import { appToNotionProps } from '@/lib/notion-sync';

async function pushToNotion(producer) {
  const token = process.env.NOTION_TOKEN;
  if (!token || !producer.notion_id) return;
  try {
    await fetch(`https://api.notion.com/v1/pages/${producer.notion_id}`, {
      method: 'PATCH',
      headers: { 'Authorization': `Bearer ${token}`, 'Notion-Version': '2022-06-28', 'Content-Type': 'application/json' },
      body: JSON.stringify({ properties: appToNotionProps(producer) }),
    });
  } catch (err) {
    console.error('[notion push]', producer.id, err.message);
  }
}

async function createInNotion(producer) {
  const token = process.env.NOTION_TOKEN;
  const dbId = process.env.NOTION_DATABASE_ID;
  if (!token || !dbId) return null;
  try {
    const res = await fetch('https://api.notion.com/v1/pages', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}`, 'Notion-Version': '2022-06-28', 'Content-Type': 'application/json' },
      body: JSON.stringify({ parent: { database_id: dbId }, properties: appToNotionProps(producer) }),
    });
    const data = await res.json();
    return res.ok ? data.id : null;
  } catch (err) {
    console.error('[notion create]', producer.id, err.message);
    return null;
  }
}

export default async function handler(req, res) {
  const { id } = req.query;

  if (req.method === 'GET') {
    const producer = await prisma.placementProducer.findUnique({ where: { id } });
    if (!producer) return res.status(404).json({ error: 'Not found' });
    return res.status(200).json(producer);
  }

  if (req.method === 'PUT') {
    const { id: _id, created_date: _cd, _type: _t, ...data } = req.body;
    try {
      const producer = await prisma.placementProducer.update({ where: { id }, data });
      // Push to Notion in background (non-blocking)
      pushToNotion(producer);
      return res.status(200).json(producer);
    } catch (err) {
      console.error('[PUT /placement-producers/:id]', err.message);
      return res.status(500).json({ error: err.message });
    }
  }

  if (req.method === 'DELETE') {
    try {
      const producer = await prisma.placementProducer.findUnique({ where: { id }, select: { notion_id: true } });
      await prisma.placementProducer.delete({ where: { id } });
      // Archive in Notion
      if (producer?.notion_id && process.env.NOTION_TOKEN) {
        fetch(`https://api.notion.com/v1/pages/${producer.notion_id}`, {
          method: 'PATCH',
          headers: { 'Authorization': `Bearer ${process.env.NOTION_TOKEN}`, 'Notion-Version': '2022-06-28', 'Content-Type': 'application/json' },
          body: JSON.stringify({ archived: true }),
        }).catch(() => {});
      }
      return res.status(200).json({ success: true });
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  res.status(405).end();
}
