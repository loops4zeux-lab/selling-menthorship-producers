/**
 * POST /api/discovery/song-producer
 * Body: { title: string, artist: string }
 *
 * Searches Genius for a song by title + artist, extracts its producer_artists,
 * fetches their Instagram handles, and returns them with isDuplicate flags.
 * Does NOT save — saving is done by the caller.
 */

import { prisma } from '@/lib/db';

const GENIUS_BASE = 'https://api.genius.com';

const STYLE_ARTISTS = {
  'Juice WRLD': 'Juice WRLD',
  'Polo G': 'Polo G',
  'Rod Wave': 'Rod Wave',
  'NBA YoungBoy': 'NBA YoungBoy',
};
const BIG_NAMES = new Set(Object.keys(STYLE_ARTISTS));

function normalizeInstagram(ig) {
  if (!ig || typeof ig !== 'string') return null;
  const handle = ig.trim().replace(/\/$/, '').split('/').pop().toLowerCase();
  return handle || null;
}

function geniusFetch(path, token) {
  return fetch(`${GENIUS_BASE}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  }).then(r => r.json());
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const token = process.env.GENIUS_TOKEN;
  if (!token) return res.status(500).json({ error: 'GENIUS_TOKEN no está configurado' });

  const { title, artist } = req.body || {};
  if (!title) return res.status(400).json({ error: 'title es requerido' });

  const query = [title, artist].filter(Boolean).join(' ');

  try {
    const [existingPL, existingYT] = await Promise.all([
      prisma.placementProducer.findMany({ select: { name: true, instagram: true } }),
      prisma.youTubeProducer.findMany({ select: { name: true, instagram: true } }),
    ]);
    const existingNames = new Set(
      [...existingPL, ...existingYT].map(p => p.name.toLowerCase())
    );
    const existingHandles = new Set(
      [...existingPL, ...existingYT].map(p => normalizeInstagram(p.instagram)).filter(Boolean)
    );

    const searchData = await geniusFetch(
      `/search?q=${encodeURIComponent(query)}`,
      token
    );
    const hits = searchData?.response?.hits ?? [];
    const songHit = hits.find(h => h.type === 'song');

    if (!songHit) return res.status(200).json({ producers: [] });

    const songData = await geniusFetch(`/songs/${songHit.result.id}`, token);
    const song = songData?.response?.song;
    if (!song) return res.status(200).json({ producers: [] });

    const songTitle = song.title || title;
    const artistName = song.primary_artist?.name || artist || '';
    const producerArtists = song.producer_artists || [];

    const producers = [];

    for (const producer of producerArtists) {
      if (!producer?.id || !producer?.name) continue;

      let instagramHandle = '';
      try {
        const artistData = await geniusFetch(`/artists/${producer.id}`, token);
        instagramHandle = artistData?.response?.artist?.instagram_name || '';
      } catch {
        // continue without instagram
      }

      const instagram = instagramHandle ? `https://instagram.com/${instagramHandle}` : '';
      const key = producer.name.toLowerCase();
      const handle = normalizeInstagram(instagram);
      const isDuplicate =
        existingNames.has(key) || (handle !== null && existingHandles.has(handle));

      const artistNames = artistName ? [artistName] : [];
      const bigNames = artistNames.filter(a => BIG_NAMES.has(a));

      producers.push({
        name: producer.name,
        instagram,
        song: songTitle,
        artist: artistName,
        placements: artistNames.join(', '),
        style: bigNames.length > 0 ? STYLE_ARTISTS[bigNames[0]] : '',
        isDuplicate,
      });
    }

    return res.status(200).json({ producers });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
