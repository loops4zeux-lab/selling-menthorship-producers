import { runNotionSync } from '@/lib/notion-sync';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { lastSyncTime } = req.body || {};
  const sinceTime = lastSyncTime ? new Date(lastSyncTime) : null;

  const start = Date.now();
  try {
    const stats = await runNotionSync(sinceTime);
    return res.status(200).json({ ok: true, stats, duration_ms: Date.now() - start, synced_at: new Date().toISOString() });
  } catch (err) {
    console.error('[notion-sync]', err);
    return res.status(500).json({ ok: false, error: err.message });
  }
}
