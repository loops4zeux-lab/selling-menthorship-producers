/**
 * POST /api/spotify/search
 * Body: { query: string }
 *
 * Searches Deezer for tracks matching the style query.
 * Deezer is free, requires no authentication, and provides 30s preview URLs.
 * Returns tracks with a preview URL only.
 */
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { query } = req.body || {};
  if (!query?.trim()) return res.status(400).json({ error: 'query es requerido' });

  try {
    const url = `https://api.deezer.com/search?q=${encodeURIComponent(query)}&limit=50&order=RANKING`;
    const response = await fetch(url);
    const data = await response.json();

    if (data.error) throw new Error(data.error.message || 'Deezer API error');

    const items = data?.data || [];
    const tracks = items
      .filter(t => t && t.preview)
      .map(t => ({
        id: String(t.id),
        title: t.title,
        artist: t.artist?.name || '',
        album: t.album?.title || '',
        albumArt: t.album?.cover_medium || t.album?.cover || null,
        previewUrl: t.preview,
        spotifyUrl: t.link || '',
      }));

    return res.status(200).json({ tracks });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
